(function($) {
    var proxypoollist = function() {
            
        }();
        jQuery(window).on('load', function() {
            setTimeout(function() {
                proxypoollist.load();
            }, 1000);
        });
})(jQuery);
