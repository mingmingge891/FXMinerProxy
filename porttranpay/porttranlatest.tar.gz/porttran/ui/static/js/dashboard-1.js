(function($) {
    
    /* "use strict" */
    var dlabChartlist = function() {
        var MemUsage =0.0;
        var CpuUsage =0.0;
        // var DiskUsage =0.0;
        // var realTimeTcpCnt =0.0;
        //内存CPU统计
        var flotRealtimeCpuAndMemFunc = function(){
            var dataMem = [], totalPoints = 50;
            var dataCpu = [];
            function getRandomDataMem() {
                if (dataMem.length > 0)
                dataMem = dataMem.slice(1);
                while (dataMem.length < totalPoints) {
                    dataMem.push(MemUsage);
                }
                var res = [];
                for (var i = 0; i < dataMem.length; ++i) {
                    res.push([i, dataMem[i]])
                }
                return res;
            }
            function getRandomDataCpu() {
                if (dataCpu.length > 0)
                dataCpu = dataCpu.slice(1);
                while (dataCpu.length < totalPoints) {
                    dataCpu.push(CpuUsage);
                }
                var res = [];
                for (var i = 0; i < dataCpu.length; ++i) {
                    res.push([i, dataCpu[i]])
                }
                return res;
            }
            // Set up the control widget
            var updateInterval = 500;
            var plot5 = $.plot('#flotRealtimeCpuAndMem', [{data:getRandomDataMem(),label:"内存"},{data:getRandomDataCpu(),label:"CPU"}], {
                colors: ['#17A2BB','#FF910F'],
                series: {
                    lines: {
                        show: true,
                        lineWidth: 0,
                        fill: 0.9
                    },
                    shadowSize: 0	// Drawing is faster without shadows
                },
                grid: {
                    borderColor: 'transparent',
                    borderWidth: 1,
                    labelMargin: 5,
                    hoverable: true, //鼠标移动
                    clickable: true, //鼠标点击
                },
                xaxis: {
                    color: 'transparent',
                    show: false,
                    font: {
                        size: 10,
                        color: '#fff'
                    }
                },
                yaxis: {
                    min: 0,
                    max: 100,
                    //color: 'transparent',
                    font: {
                        size: 15,
                        color: '#f0f0f'
                    }
                },
                legend: {
                    show: true,
                }
            });
            update_plot5();
            function update_plot5() {
                plot5.setData([{data:getRandomDataMem(),label:"内存"},{data:getRandomDataCpu(),label:"CPU"}]);
                plot5.draw();
                setTimeout(update_plot5, updateInterval);
            }
            $("#flotRealtimeCpuAndMem").bind("plothover", function(event, pos, item) {
                if (item) {
                    // var x = item.datapoint[0].toFixed(2),
                     var  y = item.datapoint[1].toFixed(2);
                    $("#linechart-tooltip").html(item.series.label +':'+ y+'%').css({ top: item.pageY + 5, left: item.pageX + 5 }).fadeIn(200);
                    console.log(item);
                } else {
                    $("#linechart-tooltip").hide();
                }
            });
            $("<div id='linechart-tooltip' class='chart-tooltip'></div>").appendTo("body");
        }
        //历史数据统计
        var HistoryStatistical = function(coinType) {
            var HashRateOptions = {
                series: [{
                    name: '算力',
                    data: [0],
                     color: 'rgba(44,160,44,0.7)',
                },{
                    name: '矿机',
                    data: [0],
                    color: 'rgba(228,115,17,0.7)',
                }, ],
                chart: {
                    type: 'line',
                    height: 300,
                    toolbar: {
                        show: false,
                    },
                },
                plotOptions: {
                    bar: {
                        horizontal: false,
                        columnWidth: '70%',
                        endingShape: 'rounded'
                    },
                },
                colors: ['#886CC0'],
                dataLabels: {
                    enabled: false,
                },
                markers: {
                    shape: "circle",
                },
                legend: {
                    show: true,
                },
                stroke: {
                    show: true,
                    width: 2,
                    curve: 'smooth',
                    colors: ['var(--primary)'],
                },
                grid: {
                    borderColor: '#eee',
                    show: true,
                    xaxis: {
                        lines: {
                            show: true,
                        }
                    },
                    yaxis: {
                        lines: {
                            show: false,
                        }
                    },
                },
                xaxis: {
                    categories: [],
                    show: false,
                    labels: {
                        style: {
                            colors: '#7E7F80',
                            fontSize: '13px',
                            fontFamily: 'Poppins',
                            fontWeight: 100,
                            cssClass: 'apexcharts-xaxis-label',
                        },
                    },
                    crosshairs: {
                        show: false,
                    }
                },
                yaxis: [{
                    show: true,
                    labels: {
                        offsetX: -15,
                        style: {
                            colors: '#7E7F80',
                            fontSize: '14px',
                            fontFamily: 'Poppins',
                            fontWeight: 100,
                        },
                        formatter: function(y) {
                            return y.toFixed(0) + "G";
                        },
                    },
                },
                {
                    show: false,
                    labels: {
                        offsetX: -15,
                        style: {
                            colors: '#7E7F80',
                            fontSize: '14px',
                            fontFamily: 'Poppins',
                            fontWeight: 100,
                        },
                        formatter: function(y) {
                            return y.toFixed(0) + "台";
                        },
                    },
                }],
                fill: {
                    opacity: 1,
                    colors: '#FAC700'
                },
                tooltip: {
                    y: [{
                        formatter: function(val) {
                            return val + " gh/s"
                        }
                    },
                    {
                        formatter: function(val) {
                            return val + "台"
                        }
                    }]
                }
            };
            var chartBarHashRate = new ApexCharts(document.querySelector("#HistoryHashrate"), HashRateOptions);
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var data = xhr.responseText;
                    data = JSON.parse(data);
                    for (var p in data.worker_info) {
                        HashRateOptions.series[0].data[p] = parseFloat(Number(data.worker_info[p].hash_rate / 1000000000).toFixed(3));
                        HashRateOptions.series[1].data[p] = data.worker_info[p].worker_cnt;
                        HashRateOptions.xaxis.categories[p] = data.worker_info[p].time;
                    }
                    document.getElementById("HistoryHashrate").innerHTML ="";
                    // HashRateOptions.yaxis[0].max = 50;
                    // HashRateOptions.yaxis[1].max = 10;
                    chartBarHashRate.render();
                }
            }
            xhr.open('GET', 'api/workerInfoHistory?coinType='+coinType, true)
            xhr.send();
        }
        //时时数据统计
        var Statistical = function() {
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (xhr.readyState == 4 && xhr.status == 200) {
                    var data = xhr.responseText;
                    data = JSON.parse(data);
                    document.getElementById("TotalWorker").innerHTML = data.eth.total_client;
                    document.getElementById("TotalShares").innerHTML = data.eth.total_share;
                    document.getElementById("TotalHashRate").innerHTML = parseFloat(Number(data.eth.total_hash_rate / 1000000000).toFixed(3));
                    document.getElementById("TotalHash1HoursShares").innerHTML = data.eth.hours_1_total_share;
                    MemUsage = parseFloat(Number(data.memory_usage+1.0).toFixed(2));
                    CpuUsage = parseFloat(Number(data.cpu_usage+1.0).toFixed(2));
                     // DiskUsage = parseFloat(Number(data.disk_usage).toFixed(2));
                    // realTimeTcpCnt = data.total_tcp_cnt;
                }
            }
            var intervalId = window.setInterval(function clock() {
                xhr.open('GET', 'api/statistical', true)
                xhr.send();
            }, 2 * 1000);
            xhr.open('GET', 'api/statistical', true)
            xhr.send();
        }
        document.getElementById("A_ETH").onclick=function(){
            HistoryStatistical("ETH");
        }
        document.getElementById("A_ETC").onclick=function(){
            HistoryStatistical("ETC");
        }
        return {
            init: function() {},
            load: function() {
                HistoryStatistical("ETH");
                Statistical();
                flotRealtimeCpuAndMemFunc();
            },
            resize: function() {}
        }
    }();
    jQuery(window).on('load', function() {
        setTimeout(function() {
            dlabChartlist.load();
        }, 1000);
    });
})(jQuery);