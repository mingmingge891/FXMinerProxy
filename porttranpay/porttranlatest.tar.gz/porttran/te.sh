sed -i 's/"is_open_general_swap": true/"is_open_general_swap": false/g' localconfig.json
